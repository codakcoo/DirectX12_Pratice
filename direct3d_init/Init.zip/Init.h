#pragma once
#include <Windows.h>
#include <d3d12.h>
#include <dxgi1_4.h>
#include <wrl.h>
#include "d3dx12.h"
#include "d3dUtil.h"


using Microsoft::WRL::ComPtr;



class Init
{
	int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow);

	LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
	bool InitWindow(HINSTANCE hInstance);
	bool InitD3D();
	void FlushCommandQueue();
	void Draw();

	void CreateCommandObjects();

protected:

	HWND gMaindWnd = nullptr;

	ComPtr<ID3D12Device> g_device;
	ComPtr<IDXGIFactory4> g_dxgiFactory;
	ComPtr<ID3D12Fence> g_fence;
	ComPtr<ID3D12CommandQueue> g_commandQueue;
	ComPtr<ID3D12CommandAllocator> g_commandAllocator;
	ComPtr<ID3D12GraphicsCommandList> g_commandList;
	ComPtr<IDXGISwapChain> g_swapChain;
	ComPtr<ID3D12DescriptorHeap> g_rtvHeap;
	ComPtr<ID3D12DescriptorHeap> g_dsvHeap;
	ComPtr<ID3D12Resource> g_SwapChainBuffer[2];
	ComPtr<ID3D12Resource> g_depthStencilBuffer;

	UINT g_rtvDescriptorSize = 0;
	UINT g_dsvDescriptorSize = 0;
	UINT g_cbvSrvUavDescriptorSize = 0;

	DXGI_FORMAT mBackBufferFormat = DXGI_FORMAT_R8G8B8A8_UNORM;
	DXGI_FORMAT mDepthStencilFormat = DXGI_FORMAT_D24_UNORM_S8_UINT;
	int mClientWidth = 800;
	int mClientHeight = 600;

	bool m4xMsaaState = false; // 4X MSAA enabled
	UINT m4xMsaaQuality = 0; // quality level of 4X MSAA
};